import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import net.sourceforge.jeval.*; 
import g4p_controls.*; 
import java.util.Iterator; 
import java.util.LinkedList; 

import net.sourceforge.jeval.operator.*; 
import net.sourceforge.jeval.*; 
import g4p_controls.*; 
import net.sourceforge.jeval.function.string.*; 
import net.sourceforge.jeval.function.math.*; 
import net.sourceforge.jeval.function.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ODE_GS extends PApplet {

////
//Search [UPDATE] to find things that need to be changed
////

///Packages//

//Package used to handle mathematical functions as input strings


//Package used to handle GUI


//Lists stuff



///Globals///

//Integration parameters
float H; //integration precision
float time; //global time
float zoom; //camera zoom

//Graphical help
float CENTERX, CENTERY;

//ODE System [UPDATE]
MathFunc F1;
MathFunc F2;

//Used to change F
String F1_str;
String F2_str;
String F1_GUI;
String F2_GUI;

//List of all orbits
LinkedList<Orbit> OrbitList;

//Jeval evaluator
Evaluator evaluator;


///Classes///

//Mathematical function. Used for parsing input equations and evaluate them.
class MathFunc {
  String math_expression_parsed; //math expression parsed on jeval format

  //Constructor
  MathFunc(String math_expression) { //raw math expression given by the user
    math_expression_parsed = math_expression.replace("x", "#{x}").replace("t", "#{t}").replace("y", "#{y}"); //input parsing into jeval format
  }

  //Evaluator
  //Returns the evaluation of the function at a given time and point
  public float result(float tvar, float xvar, float yvar) {
    
    float result = 0; //result needs to be initialized in order to be returned
    
    //Jeval storing input time and point
    //'xvar + ""' is needed in order to transform xvar into a string so Jeval can work with it
    evaluator.putVariable("x", xvar + "");
    evaluator.putVariable("y", yvar + "");
    evaluator.putVariable("t", tvar + "");
    
    //try-catch used to handle numerical EvaluationException
    try {
      result = Float.parseFloat(evaluator.evaluate(math_expression_parsed)); //Jeval at work evaluating
    }
    catch(Exception e) {
      println(e);
    }
    
    return result;
  }
}

//Orbit with a starting point
class Orbit {
  float t0, x0, y0; //starting time and point
  
  float lastX, lastY; //used with the Euler method. Needs to be re-written using pointers. [UPDATE] [EULER]
  float lastlastX, lastlastY; //same [UPDATE] [EULER]

  FloatList xhistory, yhistory; //list that contains all the points. Needs to be changed to a new point class [UPDATE] [POINTS]
  
  int orbitColor; //orbit display color
  
  float previousX, previousY; //used with display. Needs to be re-written using pointers. [UPDATE] [DISPLAY]
  
  //Constructor
  Orbit(float t0, float x0, float y0) {
    this.t0 = t0;
    this.x0 = x0;
    this.y0 = y0;
    
    xhistory = new FloatList();
    yhistory = new FloatList();
    xhistory.append(this.x0);
    yhistory.append(this.y0);
    
    lastX = this.x0;
    lastY = this.y0;
    previousX = this.x0;
    previousY = this.y0;
    
    orbitColor = color(random(255),random(255),random(255));
  } 
  
  //Display
  public void display(){
    if (time - t0 < H){
    }

    previousX = x0;
    previousY = y0;
    Iterator<Float> xiter = xhistory.iterator();
    Iterator<Float> yiter = yhistory.iterator();
    while (xiter.hasNext() && yiter.hasNext()) {
      
      float newX = xiter.next();
      float newY = yiter.next();
      stroke(orbitColor);
      line(previousX + CENTERX, -previousY + CENTERY, newX + CENTERX, -newY + CENTERY);
      previousX = newX;
      previousY = newY;
    }
  }
  
  //Update (Euler)
  public void next_point_euler(){
    lastlastX = lastX;
    lastlastY = lastY;
    lastX = lastX + H*F1.result(time, lastX, lastY);
    lastY = lastY + H*F2.result(time, lastX, lastY);
    xhistory.append(lastX);
    yhistory.append(lastY);
  }
  
  //Add a change_color function [UPDATE]
}


public void setup() {
  //GUI stuff
  createGUI();
  customGUI();
  
  evaluator = new Evaluator();
  H = 0.01f;
  frameRate(60);
  size(500,500);
  CENTERX = width/2;
  CENTERY = height/2;
  
  F1_str = "-x + y";
  F2_str = "-y - x";
  F1_GUI = "-x + y";
  F2_GUI = "-y - x";
  simulation_start();
}

public void simulation_start() {
  background(255);
  evaluator = new Evaluator();
  zoom = 1;
  OrbitList = new LinkedList<Orbit>();
  time = 0;
  F1 = new MathFunc(F1_str);
  F2 = new MathFunc(F2_str);
  println(F1_str);
  println(F2_str);
  println("------");
}

public void draw() {
  canvas_draw();
}

public void canvas_draw() {
  strokeWeight(1/zoom);
  translate(+CENTERX, +CENTERY);
  scale(zoom); 
  translate(-CENTERX, -CENTERY);
  background(255);
  Iterator<Orbit> iter = OrbitList.iterator();
  while (iter.hasNext()) {
    Orbit updateOrbit = iter.next();
    updateOrbit.next_point_euler();
    updateOrbit.display();
  }
  
  time += H; 
}

public void keyPressed() {
  if (key == 'w') {
    zoom += 0.01f;
    println(zoom);
  } 
  else if (key == 's') {
    zoom -= 0.01f;
    println(zoom);
  }
}

public void mouseClicked() {
  Orbit newOrbit = new Orbit(time, (mouseX - CENTERX)/zoom, (CENTERY - mouseY)/zoom);
  OrbitList.add(newOrbit);
}

public void customGUI(){

}
/* =========================================================
 * ====                   WARNING                        ===
 * =========================================================
 * The code in this tab has been generated from the GUI form
 * designer and care should be taken when editing this file.
 * Only add/edit code inside the event handlers i.e. only
 * use lines between the matching comment tags. e.g.

 void myBtnEvents(GButton button) { //_CODE_:button1:12356:
     // It is safe to enter your event code here  
 } //_CODE_:button1:12356:
 
 * Do not rename this tab!
 * =========================================================
 */

synchronized public void GUI_draw(GWinApplet appc, GWinData data) { //_CODE_:GUI:419809:
  appc.background(230);
} //_CODE_:GUI:419809:

public void restart_simulation(GButton source, GEvent event) { //_CODE_:button1:887050:
  F1_str = F1_GUI;
  F2_str = F2_GUI;
  simulation_start();
} //_CODE_:button1:887050:

public void textarea1_change1(GTextArea source, GEvent event) { //_CODE_:textarea1:826290:
  F1_GUI = source.getText().trim();
} //_CODE_:textarea1:826290:

public void textarea2_change1(GTextArea source, GEvent event) { //_CODE_:textarea2:713103:
  F2_GUI = source.getText().trim();
} //_CODE_:textarea2:713103:



// Create all the GUI controls. 
// autogenerated do not edit
public void createGUI(){
  G4P.messagesEnabled(false);
  G4P.setGlobalColorScheme(GCScheme.BLUE_SCHEME);
  G4P.setCursor(ARROW);
  if(frame != null)
    frame.setTitle("Sketch Window");
  GUI = new GWindow(this, "GUI", 600, 100, 240, 300, false, JAVA2D);
  GUI.setActionOnClose(G4P.CLOSE_WINDOW);
  GUI.addDrawHandler(this, "GUI_draw");
  label1 = new GLabel(GUI.papplet, 17, 25, 80, 20);
  label1.setText("F1");
  label1.setOpaque(false);
  label2 = new GLabel(GUI.papplet, 12, 101, 80, 20);
  label2.setText("F2");
  label2.setOpaque(false);
  button1 = new GButton(GUI.papplet, 12, 185, 80, 30);
  button1.setText("Restart Simulation");
  button1.addEventHandler(this, "restart_simulation");
  textarea1 = new GTextArea(GUI.papplet, 14, 53, 160, 40, G4P.SCROLLBARS_NONE);
  textarea1.setOpaque(true);
  textarea1.addEventHandler(this, "textarea1_change1");
  textarea2 = new GTextArea(GUI.papplet, 13, 131, 160, 40, G4P.SCROLLBARS_NONE);
  textarea2.setOpaque(true);
  textarea2.addEventHandler(this, "textarea2_change1");
}

// Variable declarations 
// autogenerated do not edit
GWindow GUI;
GLabel label1; 
GLabel label2; 
GButton button1; 
GTextArea textarea1; 
GTextArea textarea2; 

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ODE_GS" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
